package com.example.a2th_android;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    static int right_answer;
    static int right_count = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.times_table);

        TextView question = (TextView) findViewById(R.id.question);

        Random rand = new Random();

        int rand_val1 = rand.nextInt(9)+1;
        int rand_val2 = rand.nextInt(9)+1;
        right_answer = rand_val1 * rand_val2;


        String val1_s = Integer.toString(rand_val1);
        String val2_s = Integer.toString(rand_val2);

        //문제 textview설정
        question.setText(val1_s + "*" + val2_s + "=");

    }


    public void btn_click(View view){

        TextView answer = (TextView) findViewById(R.id.answer);
        TextView result = (TextView) findViewById(R.id.result);
        TextView count = (TextView) findViewById(R.id.count);
        TextView question = (TextView) findViewById(R.id.question);
        //int answer2 = Integer.parseInt(answer1);

        //정답 확인용
        Toast.makeText(MainActivity.this, right_answer+"", Toast.LENGTH_SHORT).show();

        String str = (String) ((Button)view).getText(); //버튼 text 추가

        if(str.equals("확인")){
            int answer2 = Integer.parseInt(answer.getText().toString());
            if( right_answer == answer2 ){
                result.setText("Success");
                count.setText((++right_count)+"");


                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                Random rand = new Random();

                int rand_val1 = rand.nextInt(9)+1;
                int rand_val2 = rand.nextInt(9)+1;
                right_answer = rand_val1 * rand_val2;

                String val1_s = Integer.toString(rand_val1);
                String val2_s = Integer.toString(rand_val2);

                question.setText(val1_s + "*" + val2_s + "=");
               /* result.setText(" ");*/
                answer.setText("");

            }
            else{
                result.setText("false");
            }
        }
        else if(str.equals("취소")) {
            answer.setText("");
        }
        else{
            answer.append(str);
        }




    }

}