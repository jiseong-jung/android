package com.example.regist_courses;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.sql.Struct;
import java.util.ArrayList;

class Student{
    String name;
    String phone;
    String subject;
    String time;
}



public class MainActivity extends AppCompatActivity {

    final static int REQUEST_CODE_START_INPUT = 1;
    String[] item = {"temp1","temp2"};

    ArrayList al;
    MyAdapter aa;
    ListView lv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        al = new ArrayList();
        aa = new MyAdapter(this, R.layout.row, al);
        lv = (ListView) findViewById(R.id.list_view);
        lv.setAdapter(aa);

        Button request_btn = (Button) findViewById(R.id.request);
        request_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, courses.class);
                startActivityForResult(intent, REQUEST_CODE_START_INPUT);

            }
        });
    }

}

class MyAdapter extends ArrayAdapter<String>{

    LayoutInflater inflater;
    ArrayList students;

    public MyAdapter(@NonNull Context context, int resource, ArrayList st) {
        super(context, resource);
        inflater = LayoutInflater.from(context);
        students = st;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        View view = convertView;

        if (view == null) {
            view = inflater.inflate(R.layout.row, null);
        }



        return view;
    }
}









