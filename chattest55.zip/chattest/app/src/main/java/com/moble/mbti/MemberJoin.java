package com.moble.mbti;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class MemberJoin extends AppCompatActivity {

    private static final String TAG = "jiseong";
    //private FirebaseFirestore db = null;

    FirebaseFirestore db = FirebaseFirestore.getInstance();

    private Button btn_join, btn_overlap;
    private EditText et_nickname;
    private String uid;
    private String str_conversion;      //CharSequence 를 String으로 받을 값
    private String spinner_mbti_result;
    private CheckBox checkBox_match;

    //값을 계속 갖고 있을것들
    private String checkBox_match_result = "false";
    private String save_str_conversion;     //중복체크를 눌렀을때의 이름 기록

    Spinner joinSpinner;
    ArrayAdapter mbtiAdapter;

    // 리스너들 모음
    AdapterView.OnItemSelectedListener listener_spinner;
    CompoundButton.OnCheckedChangeListener listener_checkbox_match;
    TextWatcher listener_et_nickname;
    View.OnClickListener listener_btn_join, listener_btn_overlap;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_member_join);

        Intent uid_info_intent = getIntent();
        uid = uid_info_intent.getStringExtra("uid");

        Log.i("jiseong","MemberJoin start "+uid);

        init();

    }

    void init(){
        setElements();
        listener_setting();     //리스너 기능 구현
        listener_link();        //리스너 연결
    }

    void listener_link(){
        btn_join.setOnClickListener(listener_btn_join);
        btn_overlap.setOnClickListener(listener_btn_overlap);
        et_nickname.addTextChangedListener(listener_et_nickname);           //EditText 가 값이 변동될 때
        checkBox_match.setOnCheckedChangeListener(listener_checkbox_match);

        mbtiAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);     //기본 제공되는 spinner
        joinSpinner.setAdapter(mbtiAdapter);

        joinSpinner.setOnItemSelectedListener(listener_spinner);
    }

    void setElements(){
        mbtiAdapter = ArrayAdapter.createFromResource(this, R.array.spnnier_mbti, android.R.layout.simple_spinner_item);
        btn_join = (Button) findViewById(R.id.btn_join);
        btn_overlap = (Button) findViewById(R.id.btn_overlap);
        et_nickname = (EditText)findViewById(R.id.et_nickname);
        checkBox_match = (CheckBox)findViewById(R.id.cb_match);
        joinSpinner = (Spinner) findViewById(R.id.sp_mbti);     //정보 입력창 스피너
    }

    void listener_setting(){

        //스피너 클릭 리스너
        listener_spinner = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                spinner_mbti_result = joinSpinner.getSelectedItem().toString();
                Log.i("jiseong",spinner_mbti_result);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        };


        //랜덤 채팅 확인 유무
        listener_checkbox_match = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean check) {
                checkBox_match_result= check+"";
                Log.i("jiseong",check+"");
            }
        };

        //EditText 에 변환이 있을 때
        listener_et_nickname = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence str, int i, int i1, int i2) {
            }
            @Override
            public void onTextChanged(CharSequence char_str, int i, int i1, int i2) {
                //6글자까지 자르기 + String으로 변환
                str_conversion = char_str.toString();

                if(str_conversion.length()>8 || str_conversion.length() < 2){
                    //Toast.makeText(MemberJoin.this,"8자리 이상 입력불가",Toast.LENGTH_SHORT).show();
                    Toast.makeText(MemberJoin.this, str_conversion,Toast.LENGTH_SHORT);
                    Log.i("jiseong",str_conversion);
                    btn_join.setEnabled(false);
                    et_nickname.setTextColor(Color.RED);
                }
                else {
                    et_nickname.setTextColor(Color.BLACK);
                }
            }
            @Override
            public void afterTextChanged(Editable editable) {

            }
        };


        listener_btn_join = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //가입하기 누르면 로그인화면으로 이동?
                //임시로 MainActivity 이동으로 수정

                Log.i("jiseong","btn_join");

                setInfo();      // UID, MBTI 정보, 닉네임, 문자 수신여부 정보 FireBase 저장
                Intent intent = new Intent(MemberJoin.this, MainActivity.class);
                intent.putExtra("uid",uid);
                intent.putExtra("mbti",spinner_mbti_result);
                intent.putExtra("nickname",str_conversion);
                intent.putExtra("msg",checkBox_match_result);




                // 싱글톤 객체에 정보 저장
                SingletonUserInfo singletonUserInfo = SingletonUserInfo.getInstance();

                singletonUserInfo.setMyNick(str_conversion);
                singletonUserInfo.setMyUid(uid);
                singletonUserInfo.setMyRC_Check(checkBox_match_result);
                singletonUserInfo.setMyMbti(spinner_mbti_result);

                Log.i("lcs", "intro singleton MyNick : " + singletonUserInfo.getUserInfo());



                startActivity(intent);
                Toast.makeText(MemberJoin.this, "회원가입 완료되었습니다", Toast.LENGTH_SHORT).show();
            }
        };

        //람다식 변환 가능
        listener_btn_overlap = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pattern =  "^[a-zA-Z0-9가-힣]*$";
                //닉네임 정규판별식
                boolean flag = Pattern.matches(pattern,str_conversion); //닉네임 규칙 판별

                Log.i("jiseong",flag+"");

                //중복클릭하면 중복 확인 후 토스트메시지 나옴
                //중복 확인을 하면 설정 하기 버튼이 활성화
                if(str_conversion.length()>8 || str_conversion.length() < 2){
                    Toast.makeText(MemberJoin.this, "2글자에서 8자리 사이만 입력 가능합니다.", Toast.LENGTH_SHORT).show();
                }
                else if(!flag){
                    Toast.makeText(MemberJoin.this, "특수문자, 자음, 모음은 사용할 수 없습니다.", Toast.LENGTH_SHORT).show();
                }
                else {
                    db.collection("InfoTest").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    String nick = document.get("nickname").toString();

                                    if(nick.equals(str_conversion)){
                                        Log.i("jiseong","MemberJoin uid = "+nick);
                                        Log.i("jiseong","same!");
                                        Toast.makeText(MemberJoin.this, "이미 사용중인 아이디입니다.", Toast.LENGTH_SHORT).show();
                                        btn_join.setEnabled(false);
                                        return;
                                    }
                                }
                                Toast.makeText(MemberJoin.this, "사용 가능한 아이디입니다.", Toast.LENGTH_SHORT).show();
                                btn_join.setEnabled(true);
                                save_str_conversion = str_conversion;
                                Log.i("jiseong","not find equal uid");
                            }
                        }
                    });

                }
            }
        };
    }

    void setInfo(){
        db = FirebaseFirestore.getInstance();
        CollectionReference info = db.collection("InfoTest");

        Map<String, Object> data1 = new HashMap<>();
        data1.put("nickname", save_str_conversion);
        data1.put("MBTI", spinner_mbti_result);
        data1.put("UID", uid);
        data1.put("msg",checkBox_match_result);
        info.document(uid).set(data1);
    }

}