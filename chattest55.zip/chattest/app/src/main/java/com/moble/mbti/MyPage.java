package com.moble.mbti;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.location.GnssAntennaInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Trace;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;


public class MyPage extends AppCompatActivity {

    String uid, mbti, nickname, msg;

    FirebaseFirestore db = FirebaseFirestore.getInstance();
    MemberJoin memberJoin ;

    ImageView img_setting;

    EditText et_nickname;                //닉네임 변경할 EditText
    Spinner mbtiSpinner;                //MBTI 선택할 Spinner
    ArrayAdapter mbtiAdapter;
    Button btn_overlap, btn_setting;

    private String spinner_mbti_result;
    private CheckBox checkBox_match;


    private String checkBox_match_result = "false";
    private String save_str_conversion;
    private String str_conversion;              //EditText 의 값을 String 으로 저장


    AdapterView.OnItemSelectedListener listener_spinner;
    private View.OnClickListener  listener_btn_overlap;
    View.OnClickListener listener_btn_setting, listener_img_setting;
    TextWatcher listener_et_nickname;
    Spinner joinSpinner;
    CompoundButton.OnCheckedChangeListener listener_checkbox_match;
    //이미지 관련
    View.OnClickListener listener_btn_photo_get, listener_btn_photo_upload;
    Uri photoUri;       //내부저장소에 있는 이미지 Uri 주소 저장
    static final int PICK_IMAGE_FROM_ALBUM = 0; // request code
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();
    Boolean flag_image_change = false;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_page);
        Log.i("jiseong","MyPage");


        init();
        //img_setting.setImageResource(R.drawable.logo);  //기본 이미지

        StorageReference pathReference = storageRef.child("images").child(uid);
        Log.i("jiseong",pathReference+"");

        if(pathReference == null){
            Log.i("jiseong","Firebase Storage 'images' 폴더가 없습니다.");
            img_setting.setImageResource(R.drawable.logo);
        }else{
            //StorageReference submitProfile = storageRef.child(uid);
            pathReference.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                @Override
                public void onSuccess(Uri uri) {
                    Log.i("jiseong","다운로드 "+uri+"");
                    Glide.with(MyPage.this).load(uri).into(img_setting);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.i("jiseong","OnFailure");
                    //img_setting.setImageResource(R.drawable.logo);  //기본 이미지
                }
            })
            ;
        }

    }


    void init(){

        get_intent();
        setElements();
        setMbtiSpinner();
        listener_setting();     //리스너 기능 구현
        listener_link();        //리스너 연결
    }

    void get_intent(){
        Intent intent = getIntent();
        uid = intent.getStringExtra("uid");
        mbti = intent.getStringExtra("mbti");
        nickname = intent.getStringExtra("nickname");
        msg = intent.getStringExtra("msg");
    }

    public void setElements() {
        Log.i("jiseong","Mypage"+"setElements");
        et_nickname = (EditText) findViewById(R.id.et_setNick);
        btn_overlap = findViewById(R.id.btn_overlap);
        btn_setting = findViewById(R.id.btn_setting);
        joinSpinner = findViewById(R.id.sp_mbti);
        checkBox_match = findViewById(R.id.cb_match);
        img_setting = (ImageView) findViewById(R.id.iv_myPage);
        et_nickname.setText(nickname);

        Log.i("jiseong","msg = "+msg);

        if(msg.equals("false")){
            checkBox_match.setChecked(false) ;
        }else{
            checkBox_match.setChecked(true) ;
        }


    }

    public void setMbtiSpinner() {
        mbtiSpinner = (Spinner) findViewById(R.id.sp_mbti);
        mbtiAdapter = ArrayAdapter.createFromResource(this, R.array.spnnier_mbti, android.R.layout.simple_spinner_item);
        mbtiAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        mbtiSpinner.setAdapter(mbtiAdapter);
        Log.i("jiseong","size:" + joinSpinner.getCount()+"");

        //값을 가져온 mbti 값과 spinner 값을 비교 후 default 설정
        for(int i = 0; i < joinSpinner.getCount();i++){
            if(joinSpinner.getItemAtPosition(i).toString().equals(mbti)){
                joinSpinner.setSelection(i);
            }
        }
    }


    void listener_link(){
        Log.i("jiseong","listener_link");
        et_nickname.addTextChangedListener(listener_et_nickname);           //EditText 가 값이 변동될 때
        btn_overlap.setOnClickListener(listener_btn_overlap);
        btn_setting.setOnClickListener(listener_btn_setting);
        checkBox_match.setOnCheckedChangeListener(listener_checkbox_match);
        joinSpinner.setOnItemSelectedListener(listener_spinner);
        img_setting.setOnClickListener(listener_img_setting);               //ImageView 를 클릭했을 때
    }

    void listener_setting(){

        Log.i("jiseong","listener_setting");

        //이미지 설정
        listener_img_setting = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag_image_change = true;
                Log.i("jiseong","ImageView click");
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, PICK_IMAGE_FROM_ALBUM);
            }
        };

        //랜덤 채팅 확인 유무
        listener_checkbox_match = new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean check) {
                checkBox_match_result = check+"";
                Log.i("jiseong",check+"");
            }
        };

        //스피너 클릭 리스너
        listener_spinner = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                spinner_mbti_result = joinSpinner.getSelectedItem().toString();
                Log.i("jiseong",spinner_mbti_result);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        };


        listener_btn_overlap = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String pattern =  "^[a-zA-Z0-9가-힣]*$";
                //닉네임 정규판별식
                boolean flag = Pattern.matches(pattern,str_conversion); //닉네임 규칙 판별

                Log.i("jiseong",flag+"");

                //중복클릭하면 중복 확인 후 토스트메시지 나옴
                //중복 확인을 하면 설정 하기 버튼이 활성화
                if(str_conversion.length()>8 || str_conversion.length() < 2){
                    Toast.makeText(MyPage.this, "2글자에서 8자리 사이만 입력 가능합니다.", Toast.LENGTH_SHORT).show();
                }
                else if(!flag){
                    Toast.makeText(MyPage.this, "특수문자, 자음, 모음은 사용할 수 없습니다.", Toast.LENGTH_SHORT).show();
                }
                else {
                    db.collection("InfoTest").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    String nick = document.get("nickname").toString();

                                    if (nick.equals(str_conversion)) {
                                        Log.i("jiseong", "MemberJoin uid = " + nick);
                                        Log.i("jiseong", "same!");
                                        Toast.makeText(MyPage.this, "이미 사용중인 아이디입니다.", Toast.LENGTH_SHORT).show();
                                        btn_setting.setEnabled(false);
                                        return;
                                    }
                                }
                                Toast.makeText(MyPage.this, "사용 가능한 아이디입니다.", Toast.LENGTH_SHORT).show();
                                btn_setting.setEnabled(true);
                                save_str_conversion = str_conversion;
                                Log.i("jiseong", "not find equal uid");
                            }
                        }
                    });
                }

            }
        };

        //정보 수정 후
        listener_btn_setting = new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String cmp_nickname = et_nickname.getText().toString();

                if(!cmp_nickname.equals(nickname)){
                    Toast.makeText(MyPage.this, "중복확인을 해주세요",Toast.LENGTH_SHORT).show();
                }else {

                    Log.i("jiseong", "setting_btn");
                    Intent it = new Intent();
                    it.setClass(MyPage.this, MainActivity.class);
                    setInfo();

                    if(flag_image_change){
                        storageRef = storage.getReference().child("images").child(uid);   //uid 로 저장
                        storageRef.putFile(photoUri);
                        Log.i("jiseong", "upload");
                    }

                    startActivity(it);
                    Toast.makeText(MyPage.this, "정보 수정이 완료되었습니다.", Toast.LENGTH_SHORT).show();
                }

            }
        };



        listener_et_nickname = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                //str_conversion = et_nickname.getText().toString();
            }
            @Override
            public void onTextChanged(CharSequence char_str, int i, int i1, int i2) {
                btn_overlap.setEnabled(true);       //별명이 바뀌면 중복확인버튼 활성화
                //btn_setting.setEnabled(false);

                //6글자까지 자르기 + String으로 변환
                str_conversion = char_str.toString();

                if(str_conversion.length()>8 || str_conversion.length() < 2){
                    //Toast.makeText(MemberJoin.this,"8자리 이상 입력불가",Toast.LENGTH_SHORT).show();
                    Toast.makeText(MyPage.this, str_conversion,Toast.LENGTH_SHORT);
                    Log.i("jiseong",str_conversion);
                    //btn_setting.setEnabled(false);
                    et_nickname.setTextColor(Color.RED);
                }
                else {
                    et_nickname.setTextColor(Color.BLACK);

                }
            }
            @Override
            public void afterTextChanged(Editable editable) {

            }
        };

    }

    void setInfo(){
        db = FirebaseFirestore.getInstance();
        CollectionReference info = db.collection("InfoTest");

        DocumentReference docRef = db.collection("InfoTest").document("nickname");


        db.collection("InfoTest").document(nickname).delete().addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {
                Log.i("jiseong", nickname);
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.i("jiseong", "필드 삭제 실패");
            }
        });

        if(et_nickname.getText().toString().equals(nickname)){
            Map<String, Object> data1 = new HashMap<>();
            data1.put("nickname", nickname);
            data1.put("MBTI", spinner_mbti_result);
            data1.put("UID", uid);
            data1.put("msg", checkBox_match_result);
            info.document(nickname).set(data1);
            return;
        }

        Map<String, Object> data1 = new HashMap<>();
        data1.put("nickname", save_str_conversion);
        data1.put("MBTI", spinner_mbti_result);
        data1.put("UID", uid);
        data1.put("msg", checkBox_match_result);
        info.document(save_str_conversion).set(data1);
        //deleteCollection("닉네임");



        SingletonUserInfo singletonUserInfo = SingletonUserInfo.getInstance();

        singletonUserInfo.setMyNick(str_conversion);
        singletonUserInfo.setMyUid(uid);
//        singletonUserInfo.setMyImgId();
        singletonUserInfo.setMyRC_Check(checkBox_match_result);
        singletonUserInfo.setMyMbti(spinner_mbti_result);

        Log.i("lcs", "intro singleton MyNick : " + singletonUserInfo.getUserInfo());


        return;


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //btn_photo_get
        if(requestCode == PICK_IMAGE_FROM_ALBUM){
            if(resultCode == Activity.RESULT_OK){

                get_Date();
                Log.i("jiseong","사진 정상작동");
                //photoUri = data.getData();
                Log.i("jiseong",photoUri+"");
                img_setting.setImageURI(photoUri);
            }
            else{
                Log.i("jiseong","!");
                finish();
            }
        }
    }
    String get_Date(){
        Date nowDate = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy년 MM월 dd일");
        String strNowDate = simpleDateFormat.format(nowDate);
        Log.i("jiseong",strNowDate);
        return strNowDate;
    }


}