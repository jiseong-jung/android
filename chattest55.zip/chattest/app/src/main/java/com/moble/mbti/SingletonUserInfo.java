package com.moble.mbti;

public class SingletonUserInfo {

    private String MyNick;
    private String MyUid;
    private String MyImgId;
    private String MyRC_Check;
    private String MyMbti;

    private static SingletonUserInfo userInfo = new SingletonUserInfo();

    private SingletonUserInfo() {
    }

    public static SingletonUserInfo getInstance() {
        if (userInfo == null) {
            userInfo = new SingletonUserInfo();
        }
        return userInfo;
    }

    public String getMyNick() {
        return MyNick;
    }

    public void setMyNick(String myNick) {
        MyNick = myNick;
    }

    public String getMyUid() {
        return MyUid;
    }

    public void setMyUid(String myUid) {
        MyUid = myUid;
    }

    public String getMyImgId() {
        return MyImgId;
    }

    public void setMyImgId(String myImgId) {
        MyImgId = myImgId;
    }

    public String getMyRC_Check() {
        return MyRC_Check;
    }

    public void setMyRC_Check(String myRC_Check) {
        MyRC_Check = myRC_Check;
    }

    public String getMyMbti() {
        return MyMbti;
    }

    public void setMyMbti(String myMbti) {
        MyMbti = myMbti;
    }

    public SingletonUserInfo getUserInfo() {
        return userInfo;
    }

}
