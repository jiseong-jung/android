package com.moble.mbti;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.FileProvider;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.InputStream;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class StorageActivity extends AppCompatActivity {

    private Button btn_photo_get, btn_photo_upload;
    private ImageView image_test;

    Uri photoUri;

    //리스너
    View.OnClickListener listener_btn_photo_get, listener_btn_photo_upload;


    static final int PICK_IMAGE_FROM_ALBUM = 0; // request code
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();
    StorageReference imagesRef = storageRef.child("images");

    StorageReference spaceRef = storageRef.child("images/space.jpg");

    //저장할 경로(폴더)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Set up an Intent to send back to apps that request a file
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_storage);


        init();





    }

    void init(){
        setElements();
        listener_setting();     //리스너 기능 구현
        listener_link();        //리스너 연결
    }

    void setElements(){
        btn_photo_get = (Button)findViewById(R.id.btn_photo_get);
        btn_photo_upload = (Button)findViewById(R.id.btn_photo_upload);
        image_test = (ImageView) findViewById(R.id.image_test);
    }

    void listener_link(){
        btn_photo_get.setOnClickListener(listener_btn_photo_get);
        btn_photo_upload.setOnClickListener(listener_btn_photo_upload);

    }

    void listener_setting(){
        
        //사진첩에서 사진 불러오기
        listener_btn_photo_get = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("jiseong","click");
                Intent photoPickerIntent = new Intent(Intent.ACTION_PICK);
                photoPickerIntent.setType("image/*");
                startActivityForResult(photoPickerIntent, PICK_IMAGE_FROM_ALBUM);
            }
        };

        listener_btn_photo_upload = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                
                storageRef.putFile(photoUri);
                Log.i("jiseong","upload");

            }
        };

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //btn_photo_get
        if(requestCode == PICK_IMAGE_FROM_ALBUM){
            if(resultCode == Activity.RESULT_OK){
                
                get_Date();
                Log.i("jiseong","사진 정상작동");
                photoUri = data.getData();                      //이미지 파일 경로
                Log.i("jiseong",photoUri+"");
                image_test.setImageURI(photoUri);
            }
            else{
                Log.i("jiseong","!");
                finish();
            }
        }
    }

    //날자
    String get_Date(){
        Date nowDate = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy년 MM월 dd일");
        String strNowDate = simpleDateFormat.format(nowDate);
        Log.i("jiseong",strNowDate);
        return strNowDate;
    }


}