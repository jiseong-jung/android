package com.moble.mbti;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyRecyclerAdapter extends RecyclerView.Adapter<MyRecyclerAdapter.ViewHolder> {

    private List<ChatRoom> ChatRoomList;
    private Context mContext;

    public MyRecyclerAdapter(Context context, List<ChatRoom> chatRoomList) {
        ChatRoomList = chatRoomList;
        mContext = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_recyclerview, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        ChatRoom chatRoom = ChatRoomList.get(position);

        holder.profile.setImageResource(chatRoom.getResourceId());
        holder.name.setText(chatRoom.getName());
        holder.message.setText(chatRoom.getMessage());
    }

    @Override
    public int getItemCount() {
        return ChatRoomList == null ? 0 : ChatRoomList.size();
    }

    public void addChatR(ChatRoom chatRoom) {
        ChatRoomList.add(chatRoom);
        notifyItemInserted(ChatRoomList.size() - 1);
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView profile;
        TextView name;
        TextView message;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            profile = (ImageView) itemView.findViewById(R.id.profile);
            name = (TextView) itemView.findViewById(R.id.name);
            message = (TextView) itemView.findViewById(R.id.message);

//            itemView.setEnabled(true);
//            itemView.setClickable(true);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();

                    Log.i("lcs", "position : " + position);
                    Log.i("lcs", "myNick : " + ChattingRoomList.MyNick);
                    for (int i = 0; i < ChattingRoomList.myCRList.size(); i++) {
                        Log.i("lcs", "myCRList(" + i +") : " + ChattingRoomList.myCRList.get(i));
                    }

                    String CR_Id = ChattingRoomList.MyNick + "," + ChattingRoomList.myCRList.get(position);
                    Log.i("lcs", CR_Id);
                    Intent intent = new Intent();
                    intent.setClass(mContext, ChatActivity.class)
                            .putExtra("MyNick", ChattingRoomList.MyNick)
                            .putExtra("CR_Id", CR_Id);

                    mContext.startActivity(intent);
                }
            });
        }
    }
}