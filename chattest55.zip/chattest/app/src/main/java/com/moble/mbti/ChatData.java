package com.moble.mbti;

import java.util.Date;

//DTO
public class ChatData{
    private String msg;
    private String nickname;
    private Date timestamp;

    public ChatData(){}

    public ChatData(String msg, String nickname, Date timestamp) {
        this.msg = msg;
        this.nickname = nickname;
        this.timestamp = timestamp;
    }
    public ChatData(String msg, String nickname) {
        this.msg = msg;
        this.nickname = nickname;
    }

    public String getMsg() { return msg; }

    public void setMsg(String msg) { this.msg = msg; }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) { this.nickname = nickname ; }

    public Date getTimestamp() { return timestamp; }

    public void setTimestamp(Date timestamp) { this.timestamp = timestamp; }

}


