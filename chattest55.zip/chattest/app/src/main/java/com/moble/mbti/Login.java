package com.moble.mbti;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.firebase.ui.auth.AuthUI;
import com.firebase.ui.auth.FirebaseAuthUIActivityResultContract;
import com.firebase.ui.auth.IdpResponse;
import com.firebase.ui.auth.data.model.FirebaseAuthUIAuthenticationResult;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import java.util.Arrays;
import java.util.List;
import android.widget.Toast;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

//로그인 되어 있는 정보가 없을때 로그인을 진행할 액티비티
public class Login extends AppCompatActivity  {

    FirebaseFirestore db = FirebaseFirestore.getInstance();
    private FirebaseAuth mAuth;
    private GoogleSignInClient mGoogleSignInClient;
    Intent intent = new Intent();
    private SignInButton btn_login;
    private static final int RC_SIGN_IN = 9001;
    //List<AuthUI.IdpConfig> providers;

    FirebaseUser userUid;


    /*private final ActivityResultLauncher<Intent> signInLauncher = registerForActivityResult(
            new FirebaseAuthUIActivityResultContract(),
            new ActivityResultCallback<FirebaseAuthUIAuthenticationResult>() {
                @Override
                public void onActivityResult(FirebaseAuthUIAuthenticationResult result) {
                    onSignInResult(result);
                }
            }
    );*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        mAuth = FirebaseAuth.getInstance();     //firebaseAuth 객체의 공유 인스턴스를 가져옴

        btn_login = findViewById(R.id.btn_login);

        // googleSingInOptions 객체 구성할때 requestIdToken 호출함
        //로그인 후 다음 어플리케이션을 켰을때 바로 다음 화면으로 넘어가기?
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        mGoogleSignInClient.signOut();  // 재로그인시 자동 로그인 방지



/*        //로그인 방법 리스트
        providers = Arrays.asList(
                new AuthUI.IdpConfig.GoogleBuilder().build(),
                new AuthUI.IdpConfig.EmailBuilder().build(),
                new AuthUI.IdpConfig.PhoneBuilder().build()
        );*/
        
        //btn_logout.setOnClickListener(btn_logout_listener);
        btn_login.setOnClickListener(btn_login_listener);
    }



    View.OnClickListener btn_login_listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            //로그인 dialog
            signIn();

        }
    };


    /*//로그인이 되었을시? (메서드 확인 필요)
    private void onSignInResult(FirebaseAuthUIAuthenticationResult result) {
        IdpResponse response = result.getIdpResponse();
        if (result.getResultCode() == RESULT_OK) {
            // Successfully signed in
            //btn_uid.setVisibility(View.GONE);
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            Toast.makeText(Login.this,user+" = uid",Toast.LENGTH_SHORT).show();

            // ...
        } else {
            // Sign in failed. If response is null the user canceled the
            // sign-in flow using the back button. Otherwise check
            // response.getError().getErrorCode() and handle the error.
            // ...
        }
    }*/

    //로그인
    private void signIn() {
        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }


    //signIn()함수 startActivityForResult의 결과
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            try {
                // Google Sign In was successful, authenticate with Firebase
                GoogleSignInAccount account = task.getResult(ApiException.class);
                Log.i("jiseong", "firebaseAuthWithGoogle:" + account.getId());
                firebaseAuthWithGoogle(account.getIdToken());

                //t2
                /*userUid = FirebaseAuth.getInstance().getCurrentUser();
               // String uid = userUid.getUid();
                Intent intent = new Intent();
                intent.setClass(Login.this, MemberJoin.class);
                //intent.putExtra("uid", uid);
                startActivity(intent);*/

            } catch (ApiException e) {
                // Google Sign In failed, update UI appropriately
                Log.w("jiseong", "Google sign in failed", e);
            }
        }
    }

    //정상적으로 로그인하였는지 토큰 확인
    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            Log.i("jiseong", "signInWithCredential:success");
                            FirebaseUser user = mAuth.getCurrentUser();
                            //updateUI(user);
                            String uid = user.getUid();
                            Log.i("jiseong","Login + "+ uid);


                            db.collection("InfoTest").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<QuerySnapshot> task) {
                                    if (task.isSuccessful()) {
                                        for (QueryDocumentSnapshot document : task.getResult()) {
                                            String str_uid = document.get("UID").toString();
                                            Log.i("jiseong","Intro str uid = "+str_uid);
                                            if(str_uid.equals(uid)){
                                                Log.i("jiseong","find equal uid");
                                                String str_mbti = document.get("MBTI").toString();
                                                String str_nickname = document.get("nickname").toString();
                                                String str_msg = document.get("msg").toString();

                                                intent.putExtra("uid",uid);
                                                intent.putExtra("mbti",str_mbti);
                                                intent.putExtra("nickname", str_nickname);
                                                intent.putExtra("msg",str_msg);
//
//                            Log.i("jiseong",str_mbti);
//                            Log.i("jiseong",str_nickname);
//                            Log.i("jiseong",str_msg);
                                                intent.setClass(Login.this, MainActivity.class);
                                                startActivity(intent);
                                                return;
                                            }
                                        }
                                        Log.i("jiseong", "signInWithCredential:failure", task.getException());
                                        intent.putExtra("uid",uid);
                                        intent.setClass(Login.this, MemberJoin.class);
                                        startActivity(intent);


                                    }
                                }
                            });

                        }
                    }
                });
    }

    private void updateUI(FirebaseUser user) {
        //t1
        //updateUI(user);
        String uid = user.getUid();
        Log.i("jiseong","Login ?+ "+ uid);
        Intent intent = new Intent();
        intent.setClass(Login.this, MemberJoin.class);
        intent.putExtra("uid", uid);
        Log.i("jiseong","start before");
        startActivity(intent);
        finish();
    }
}


