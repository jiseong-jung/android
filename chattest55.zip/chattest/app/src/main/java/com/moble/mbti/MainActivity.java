package com.moble.mbti;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;
import java.net.URI;

public class MainActivity extends AppCompatActivity {

    Button btn1, btn2, btn3;
    //Spinner sp_my, sp_mbti;

    private ImageView ivMenu;
    private DrawerLayout drawerLayout;
    private Toolbar toolbar;
    private NavigationView navigationView;
    private TextView tv_mbti;
    private TextView tv_nickname;
    //TextView tv;
    Button btn_logout;
    //Button btn_test;
    View nav_header_view;
    String filepath;

    //mbti 정보들
    String uid, mbti, nickname, msg;
    ImageView img_Profile;
    Intent intent_get;

//    String arrList[] = {"ESFP", "INTP", "ENTJ", "ENTP", "INFJ", "INFP", "ENFJ", "ENFP",
//            "ISTJ", "ISFJ", "ESTJ", "ESFJ", "ISTP", "ISFP", "ESTP", "INTJ"};

    //이미지 파일 절대경로
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();
    StorageReference pathRef;
    String tempFilePath;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        init();
        Log.i("jiseong","mainActivity start");
        intent_get = getIntent();

        intent_data_setting(intent_get);

        setSupportActionBar(toolbar);                       //툴바 생성
        homeCall();


        setBtn();
//        setSpinner();



        //img_Profile.setImageURI(Uri.parse(filepath));

    }
    //켰을 때 fragment home_Activity 가 되게 설정  - 기존은 MainActivity가 실행됨
    void homeCall() {
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        Home fragment1 = new Home();
        transaction.replace(R.id.frame, fragment1);
        transaction.commit();
    }

    void init(){
        setElements();
        listener_ling();
    }

    void listener_ling(){
        ivMenu.setOnClickListener(listener_drawer);         //햄버거 버튼(사이드 바) 클릭시
        btn_logout.setOnClickListener(listener_btn_logout);
        navigationView.setNavigationItemSelectedListener(listener_itemselected);
    }
    void setElements(){

        drawerLayout = findViewById(R.id.drawer);           //메인(drawer)
        ivMenu = findViewById(R.id.iv_menu);
        toolbar = findViewById(R.id.toolbar);               //툴바 생성(drawer 밑)
        btn_logout = findViewById(R.id.btn_logout1);


        navigationView = findViewById(R.id.navigation);     //네비게이션
        nav_header_view = navigationView.getHeaderView(0);

        img_Profile = (ImageView) nav_header_view.findViewById(R.id.image);
        tv_mbti = (TextView)nav_header_view.findViewById(R.id.tv_mbti_output);
        tv_nickname =  (TextView) nav_header_view.findViewById(R.id.tv_nickname_output);
        tv_nickname.setText(nickname);
        tv_mbti.setText(mbti);

    }

    NavigationView.OnNavigationItemSelectedListener listener_itemselected = new NavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            int id = item.getItemId();

            if (id == R.id.menu_item1) {
                Intent intent = new Intent(MainActivity.this, MyPage.class);
                intent.putExtra("uid",uid);
                intent.putExtra("mbti",mbti);
                intent.putExtra("nickname",nickname);
                intent.putExtra("msg",msg);
                startActivity(intent);
                Toast.makeText(MainActivity.this, "item1", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.menu_item2) {
//                    tv.setText("item2");
                Toast.makeText(MainActivity.this, "item2", Toast.LENGTH_SHORT).show();
            }


            //DrawerLayout drawer = findViewById(R.id.drawer_layout);
            //drawer.closeDrawer(GravityCompat.START);
            return true;
        }
    };

    //햄버거 버튼(사이드 바) 클릭시
    View.OnClickListener listener_drawer = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            drawerLayout.openDrawer(Gravity.RIGHT);

            pathRef = storageRef.child("images/" + uid);
            try {
                File localFile = File.createTempFile("images", "jpg");


                pathRef.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                    @Override
                    public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                        Log.i("jiseong", "local file create success");
                        tempFilePath = localFile.getAbsolutePath();      //사진이 저장되는 절대경로
                        Log.i("jiseong", "filePath" + tempFilePath);
                        img_Profile.setImageURI(Uri.parse(tempFilePath));
                    }
                });

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    };

    public void setBtn() {
        btn1 = (Button) findViewById(R.id.btn_home);
        btn2 = (Button) findViewById(R.id.btn_chat);
        btn3 = (Button) findViewById(R.id.btn_matching);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                Home fragment1 = new Home();
                transaction.replace(R.id.frame, fragment1);
                transaction.commit();
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                ChattingRoomList fragment2 = new ChattingRoomList();
                transaction.replace(R.id.frame, fragment2);
                transaction.commit();
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
                Matching fragment3 = new Matching();
                transaction.replace(R.id.frame, fragment3);
                transaction.commit();
            }
        });
    }


    //사이드바 열려있을때 뒤로가기를 누를때 앱 종료가 아닌 사이드바가 닫힘
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    View.OnClickListener listener_btn_logout = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Log.i("jiseong","MainActivity 에서 Logout");
            FirebaseAuth.getInstance().signOut();       //구글 계정 로그아웃
            Intent intent = new Intent();
            intent.setClass(MainActivity.this,Login.class);

            startActivity(intent);
        }

    };

    void intent_data_setting(Intent intent_get){

        uid = intent_get.getStringExtra("uid");
        mbti = intent_get.getStringExtra("mbti");
        nickname = intent_get.getStringExtra("nickname");
        msg = intent_get.getStringExtra("msg");

        Log.i("jiseong","main uid = "+uid);
        Log.i("jiseong","main mbti = "+mbti);
        Log.i("jiseong","main nickname = "+nickname);
        Log.i("jiseong","main msg = "+msg);
        Toast.makeText(MainActivity.this, nickname+"님 환영합니다.", Toast.LENGTH_SHORT).show();


    }
}
