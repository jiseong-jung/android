package com.moble.mbti;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// 리사이클러뷰를 사용하기 위해서는 반드시 개발자가 어댑터를 직접 구현해야 한다.
// 그리고 이 때 새로 만드는 어댑터는 RecyclerView.Adapter를 상속하여 구현해야 한다.
public class ChatAdapter extends RecyclerView.Adapter<ChatAdapter.MyViewHolder> {
    // List는 클래스가 아닌 인터페이스
    // 인터페이스는 객체를 생성 할 수 없기 때문에 생성사를 가질 수 없다.
    // 인터페이스는 모든 메서드가 구현되어있지 않은 추상메서드로 이루어져있음음
    private List<ChatData> chatList;
    private String name;

    public ChatAdapter(List<ChatData> chatList, String name) {
        this.chatList = chatList;
        this.name = name;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {      // viewType 형태의 아이템 뷰를 위한 뷰홀더 객체 생성.
        // LayoutInflater.from(parent.getContext()) -> 부모의 컨텐츠를 받는 LayoutInflater를 생성
        // 레이아웃 XML파일을 View객체로 만들기 위해서는 LayoutInflater내의 inflater 메서드를 사용.
        // attachToRoot가 false일 경우에는 LayoutParams값을 설정해주기 위한 상위 뷰
        LinearLayout linearLayout = (LinearLayout) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_chat, parent, false);
        MyViewHolder myViewHolder = new MyViewHolder(linearLayout);

        return myViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {         // position에 해당하는 데이터를 뷰홀더의 아이템뷰에 표시.
        ChatData chat = chatList.get(position);

        holder.nameText.setText(chat.getNickname());
        holder.msgText.setText(chat.getMsg());

        // 만약에 사용자이름과 데이터베이스에 저장된 이름이 같을 시 오른쪽 정렬하고 아닐 시 왼쪽으로 정렬하여
        // 자신이 보낸 채팅과 남이 보낸 채팅을 구별합니다.
        if (chat.getNickname().equals(this.name)) {
            holder.nameText.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
            holder.msgText.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_END);
            holder.msgLinear.setGravity(Gravity.RIGHT);
        } else {
            holder.nameText.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
            holder.msgText.setTextAlignment(View.TEXT_ALIGNMENT_VIEW_START);
            holder.msgLinear.setGravity(Gravity.LEFT);
        }

    }

    @Override
    public int getItemCount() { return chatList == null ? 0 : chatList.size(); }      // 전체 아이템 갯수 리턴.

    public void addChat(ChatData chat) {
        chatList.add(chat);

        // position의 위치에 새로 삽입된 아이템이 있음을 옵저버에 알려 반영한다.
        notifyItemInserted(chatList.size() - 1);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        public TextView nameText;
        public TextView msgText;
        public View rootView;
        public LinearLayout msgLinear;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            nameText = itemView.findViewById(R.id.TextView_nickname);
            msgText = itemView.findViewById(R.id.TextView_msg);
            rootView = itemView;
            msgLinear = itemView.findViewById(R.id.msgLinear);

            itemView.setEnabled(true);
            itemView.setClickable(true);
        }
    }
}
