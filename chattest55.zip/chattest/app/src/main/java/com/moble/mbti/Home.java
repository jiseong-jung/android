package com.moble.mbti;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import org.w3c.dom.Text;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

public class Home extends Fragment {
    FirebaseFirestore db = FirebaseFirestore.getInstance();

    //lcs
    View v;
    TextView mbti_textview;
    ImageView mbti_imageview;
    ImageView mbti_celeb;
    private final String MyNick = "LCStest";



    //    private final String MyNick = "test";
    private ArrayList<String> destNick;
    private ArrayList<String> runningCR_Nick;
    private String CR_Id;

    //날짜 가져오기
    long now = System.currentTimeMillis();
    Date mDate=new Date(now);
    SimpleDateFormat simpleDate = new SimpleDateFormat("dd");
    String getTime = simpleDate.format(mDate);

    int int_getTime = Integer.parseInt(getTime);



    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v=inflater.inflate(R.layout.activity_home,container,false);

        mbti_celeb = (ImageView) v.findViewById(R.id.mbti_celeb);
        mbti_textview = (TextView)v.findViewById(R.id.mbti_text);
        mbti_imageview=(ImageView)v.findViewById(R.id.mbti_image);

        setDestNick();

        Button btn_rm = (Button) v.findViewById(R.id.btn_rm);
        btn_rm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.i("lcs", "rm버튼 안으로 들어옴");

                setParticipant();

                Intent intent = new Intent();
                intent.setClass(getActivity(), ChatActivity.class)
                        .putExtra("MyNick", MyNick)
                        .putExtra("CR_Id", CR_Id);
                startActivity(intent);
            }
        });

        DocumentReference mbti = db.collection("MbtiInfo").document("TODAY"); // Firebase에 저장되어있는 mbti 궁합 찾아가기
        mbti.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();
                    if (document.exists()) {
                        int num=1;


                        switch (int_getTime) {
                            case 1:
                            case 2:
                                num = 2;
                                break;
                            case 3:
                                num = 3;
                                break;
                            case 4:
                                num = 4;
                                break;
                            case 5:
                                num = 5;
                                break;
                            case 6:
                                num = 6;
                                break;
                            case 7:
                                num = 7;
                                break;
                            case 8:
                                num = 8;
                                break;
                            case 9:
                                num = 9;
                                break;
                            case 10:
                                num = 10;
                                break;
                            case 11:
                                num = 11;
                                break;
                            case 12:
                                num = 12;
                                break;
                            case 13:
                                num = 13;
                                break;
                            case 14:
                                num = 14;
                                break;
                            case 15:
                                num = 15;
                                break;
                            case 16:
                                num = 16;
                                break;
                            default:
                                num = int_getTime - 16;
                        }
                        mbti_textview.setText("오늘의 MBTI  \n \n"+document.get("data"+num).toString()+"\n"+document.get("data"+num+"_info"));
                        Log.i("firebaase", String.valueOf(document.getData()));





                    } else {
                        mbti_textview.setText("실패");
                        Log.i("firebaase", "실패");
                    }
                } else {
                    Log.i("firebaase", String.valueOf(task.getException()));

                }
            }
        });



        return v;





    }

    void setParticipant() {
        // realtimebase
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("chatRoomDATA");

        Collections.shuffle(destNick);
        CR_Id = MyNick + "," + destNick.get(0).toString();

        ChatRoom cr = new ChatRoom(destNick.get(0), "test", R.drawable.image);
        myRef.child(MyNick).push().setValue(cr);

        cr = new ChatRoom(MyNick, "test", R.drawable.image);
        myRef.child(destNick.get(0)).push().setValue(cr);
    }

    void setDestNick() {
        destNick = new ArrayList<String>();
        runningCR_Nick = new ArrayList<String>();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("chatRoomDATA");

        FirebaseFirestore firestore = FirebaseFirestore.getInstance();  // firestore

        myRef.child(MyNick).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    for (DataSnapshot snapshot : task.getResult().getChildren()) {
                        Log.i("lcs", "채팅방이 만들어진 유저 : " + snapshot.child("name").getValue().toString());
                        runningCR_Nick.add(snapshot.child("name").getValue().toString());
                    }


                    firestore.collection("InfoTest").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (QueryDocumentSnapshot document : task.getResult()) {
                                    Log.i("lcs", "user : " + document.getId());

                                    if (!document.getId().equals(MyNick) && document.get("msg").equals("true") && !runningCR_Nick.contains(document.getId())) {
                                        Log.i("lcs", "조건에 부합하는 유저 : " + document.getId());
                                        destNick.add(document.getId());
                                    }
                                }
                            } else {
                                Log.d("lcs", "get failed with ", task.getException());
                            }

                        }
                    });


                } else {
                    Log.d("lcs", "get failed with ", task.getException());
                }
            }
        });
    }
}