package com.moble.mbti;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.navigation.NavigationView;
import com.google.firebase.Timestamp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class
ChatActivity extends AppCompatActivity {

    
    private Toolbar toolbar;
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;

    // RecyclerView를 사용하면서 상하로 리스트를 보여줄 것인지, 좌우로 리스트를 보여줄것인지
    // Grid형식으로 리스트를 보여줄 것인지에 대한 타입을 지정해준다
    private RecyclerView.LayoutManager mLayoutManager;
    private List<ChatData> chatList;
//    private String nickname;

    //appbar 관련된 선언
    private DrawerLayout drawer_chat;      //chat.xml 의 가장 큰 layout
    private ImageView imageView_overflow;
    private NavigationView navigationView;
    View nav_header_view;

    private EditText EditText_chat;
    private Button Button_send;
    private DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        //appbar 관련
        drawer_chat = findViewById(R.id.drawer_chat);
        toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        imageView_overflow = (ImageView)findViewById(R.id.imageview_overflow);
        navigationView = findViewById(R.id.navigation);

        navigationView.setNavigationItemSelectedListener(listener_itemselected);
        nav_header_view = navigationView.getHeaderView(0);
        imageView_overflow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer_chat.openDrawer(Gravity.LEFT);
            }
        });
        
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setHomeAsUpIndicator(R.drawable.logo);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);
//        getSupportActionBar().setDisplayShowTitleEnabled(false);

        Intent intent = getIntent();
//        String nickname = "TestGuest2";  // 이름을 파이어스토어에서 불러와 넣어준다.
        String MyNick = getIntent().getStringExtra("MyNick");
        String CR_Id = getIntent().getStringExtra("CR_Id");

        Button_send = findViewById(R.id.Button_send);
        EditText_chat = findViewById(R.id.EditText_chat);

        mRecyclerView = findViewById(R.id.my_recycler_view);
        mRecyclerView.setHasFixedSize(true);

        // LinearLayoutManager : 수평,수직으로 배치시켜주는 레이아웃 매니저입니다.
        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);

        chatList = new ArrayList<>();

        mAdapter = new ChatAdapter(chatList, MyNick);
        mRecyclerView.setAdapter(mAdapter);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("ChatData").child(CR_Id);  //대화방 구분할때 써야할듯.

        Button_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String msg = EditText_chat.getText().toString();

                if (msg != null) {
//                    ChatData chat = new ChatData(msg, nickname);
                    ChatData chat = new ChatData(msg, MyNick, Timestamp.now().toDate());
                    myRef.push().setValue(chat);  // db에 값을 넣어줌
                    EditText_chat.setText("");
                }
            }
        });

        // 정보가 바뀌었을때 호출, 경로의 전체 내용에 대한 변경 사항을 읽고 수신 대기한다.
        myRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                ChatData chat = dataSnapshot.getValue(ChatData.class);
                ((ChatAdapter) mAdapter).addChat(chat);
                mRecyclerView.scrollToPosition(mRecyclerView.getAdapter().getItemCount() - 1);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    View.OnClickListener listener_drawer = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            drawer_chat.openDrawer(Gravity.LEFT);
        }
    };

    NavigationView.OnNavigationItemSelectedListener listener_itemselected = new NavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            int id = item.getItemId();
            Log.i("lcs","click");
            if (id == R.id.menu_item1) {
                Toast.makeText(ChatActivity.this, "item1", Toast.LENGTH_SHORT).show();
            } else if (id == R.id.menu_item2) {
//                    tv.setText("item2");
                Toast.makeText(ChatActivity.this, "item2", Toast.LENGTH_SHORT).show();
            }


            //DrawerLayout drawer = findViewById(R.id.drawer_layout);
            //drawer.closeDrawer(GravityCompat.START);
            return true;
        }
    };


}


