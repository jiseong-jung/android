package com.moble.mbti;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.List;

public class CRL_Activity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mRecyclerAdapter;
    private List<ChatRoom> ChatRoomList;
    private DatabaseReference myRef;
    static ArrayList<String> myCRList;
    static String MyNick;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crl);

        Intent intent = getIntent();
        MyNick = getIntent().getStringExtra("MyNick");

        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this, RecyclerView.VERTICAL, false));

        ChatRoomList = new ArrayList<>();

        mRecyclerAdapter = new MyRecyclerAdapter(CRL_Activity.this, ChatRoomList);
        mRecyclerView.setAdapter(mRecyclerAdapter);

        // test로 값 넣어준 코드
//        ChatRoom cr = new ChatRoom("test", "testMessage", R.drawable.maan);

        //database 선언과 생성
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("chatRoomDATA");

        // db에 값 넣어주기
//        myRef.push().setValue(cr);
//        myRef.child("test").setValue(cr);

        myCRList = new ArrayList<String>();
//        myRef.child(MyNick).addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                for (DataSnapshot data : snapshot.getChildren()) {
//                        Log.i("lcs", data.);
////                    myCRList.add(data.getKey());
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                Log.i("lcs", "실행 실패");
//            }
//        });

        myRef.child(MyNick).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    for (DataSnapshot snapshot : task.getResult().getChildren()) {
//                        Log.i("lcs", snapshot.child("name").getValue().toString());
                        myCRList.add(snapshot.child("name").getValue().toString());
                    }
                } else
                    Log.d("lcs", "get failed with ", task.getException());
            }
        });

        myRef.child(MyNick).addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {
                ChatRoom chatRoom = snapshot.getValue(ChatRoom.class);
                ((MyRecyclerAdapter) mRecyclerAdapter).addChatR(chatRoom);
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, @Nullable String previousChildName) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
}