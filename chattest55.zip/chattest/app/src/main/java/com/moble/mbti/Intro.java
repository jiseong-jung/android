package com.moble.mbti;

import android.content.Intent;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.File;
import java.io.IOException;

//앱 시작시 제일 처음 호출되는 Activity
public class Intro extends AppCompatActivity {

    //이미지 불러오기
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();
    StorageReference pathRef;
    String tempFilePath;

    FirebaseFirestore db = FirebaseFirestore.getInstance();
    static final int PROGRESSBAR_START = 1;
    ProgressBar pb;
    private String uid = null;
    Intent intent;


    String str_mbti;
    String str_nickname;
    String str_msg;


    //값 불러오는 progressbar 로 변경
    Handler handler = new Handler(Looper.getMainLooper()) {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);

            if (msg.what == PROGRESSBAR_START) {

                //intent 불러오기
                if (pb.getProgress() == 0) {
                    intent = new Intent();
                    FirebaseUser userUid = FirebaseAuth.getInstance().getCurrentUser();

                    if (userUid == null) {
                        Log.i("jiseong", "userUid is null");
                        Logged_none_init(intent);
//                        Log.i("jiseong", userUid.toString());
                    }


                    //현재 uid 가 없고 uid 필드 값이 있을때
                    else if (userUid != null) {
                        uid = userUid.getUid();
                        Log.i("jiseong", "userUid not null+ " + uid);

                    }
//                    pb.setProgress(pb.getProgress() + 1);
//                    sendEmptyMessageDelayed(PROGRESSBAR_START, 50);
                }

                //todo 이미지 다운로드 진행
                else if (pb.getProgress() == 1) {
                    pathRef = storageRef.child("images/" + uid);
                    try {
                        File localFile = File.createTempFile("images", "jpg");


                        pathRef.getFile(localFile).addOnSuccessListener(new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
                            @Override
                            public void onSuccess(FileDownloadTask.TaskSnapshot taskSnapshot) {
                                Log.i("jiseong", "local file create success");
                                tempFilePath = localFile.getAbsolutePath();      //사진이 저장되는 절대경로
                                Log.i("jiseong", "filePath" + tempFilePath);


                                // 싱글톤 객체에 정보 저장
                                SingletonUserInfo singletonUserInfo = SingletonUserInfo.getInstance();

                                singletonUserInfo.setMyNick(str_nickname);
                                singletonUserInfo.setMyUid(uid);
                                singletonUserInfo.setMyImgId(tempFilePath);
                                singletonUserInfo.setMyRC_Check(str_msg);
                                singletonUserInfo.setMyMbti(str_mbti);

                                Log.i("lcs", "intro singleton MyNick : " + singletonUserInfo.getUserInfo());


                            }
                        });

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
//                    pb.setProgress(pb.getProgress() + 1);
                    Logged_past_init(intent, uid);
                }

                if (pb.getProgress() < pb.getMax()) {
                    Log.i("lcs", "getProgress");
                    pb.setProgress(pb.getProgress() + 1);
                    sendEmptyMessageDelayed(PROGRESSBAR_START, 1000);
                }

            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        pb = (ProgressBar) findViewById(R.id.progressBar);

        Thread thread = new Thread("thread") {
            @Override
            public void run() {
                handler.sendEmptyMessage(PROGRESSBAR_START);
                super.run();
            }
        };
        thread.start();
        pb.setProgress(0);

    }


    //현재 로그인 되어 있는 uid
    void Logged_past_init(Intent intent, String uid) {
        db.collection("InfoTest").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    for (QueryDocumentSnapshot document : task.getResult()) {
                        String str_uid = document.get("UID").toString();
                        Log.i("jiseong", "Intro str uid = " + str_uid);
                        if (str_uid.equals(uid)) {
                            Log.i("jiseong", "find equal uid");
                            str_mbti = document.get("MBTI").toString();
                            str_nickname = document.get("nickname").toString();
                            str_msg = document.get("msg").toString();

                            intent.putExtra("uid", uid);
                            intent.putExtra("mbti", str_mbti);
                            intent.putExtra("nickname", str_nickname);
                            intent.putExtra("msg", str_msg);


//
//                            Log.i("jiseong",str_mbti);
//                            Log.i("jiseong",str_nickname);
//                            Log.i("jiseong",str_msg);
                            intent.setClass(Intro.this, MainActivity.class);
                            startActivity(intent);
                            //finish();
                            return;


                        }
                    }
                    Log.i("jiseong", "not find equal uid");
//                    Logged_none_init(intent);

                }
            }
        });
    }

    void Logged_none_init(Intent intent) {
        Log.i("jiseong", "none_init");
        intent.setClass(Intro.this, Login.class);
        startActivity(intent);
        finish();
        return;
    }

}